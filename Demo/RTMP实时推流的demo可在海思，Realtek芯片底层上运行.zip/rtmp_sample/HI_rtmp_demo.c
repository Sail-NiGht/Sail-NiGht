#include <stdio.h>
#include <stdlib.h>
#include "Gree_rtmp.h"
#include "rtmp.h"   
#include "rtmp_sys.h"   
#include "amf.h" 
//#include "sps_decode.h"




#define RTMP_HEAD_SIZE   (sizeof(RTMPPacket)+RTMP_MAX_HEADER_SIZE)

#define BUFFER_SIZE 32768

#define GOT_A_NAL_CROSS_BUFFER BUFFER_SIZE+1
#define GOT_A_NAL_INCLUDE_A_BUFFER BUFFER_SIZE+2
#define NO_MORE_BUFFER_TO_READ BUFFER_SIZE+3
#define false 0
#define true 1


typedef struct _NaluUnit  
{  
	int type;  
    int size;  
	unsigned char *data;  
}NaluUnit;


typedef struct _RTMPMetadata  
{  
	// video, must be h264 type   
	unsigned int    nWidth;  
	unsigned int    nHeight;  
	unsigned int    nFrameRate;      
	unsigned int    nSpsLen;  
	unsigned char   *Sps;  
	unsigned int    nPpsLen;  
	unsigned char   *Pps;   
} RTMPMetadata,*LPRTMPMetadata;  

enum  
{  
	 VIDEO_CODECID_H264 = 7,  
};  


int InitSockets()    
{    
	#ifdef WIN32     
		WORD version;    
		WSADATA wsaData;    
		version = MAKEWORD(1, 1);    
		return (WSAStartup(version, &wsaData) == 0);    
	#else     
		return TRUE;    
	#endif     
}

 
inline void CleanupSockets()    
{    
	#ifdef WIN32     
		WSACleanup();    
	#endif     
}    


char * put_byte( char *output, uint8_t nVal )    
{    
	output[0] = nVal;    
	return output+1;    
}   

char * put_be16(char *output, uint16_t nVal )    
{    
	output[1] = nVal & 0xff;    
	output[0] = nVal >> 8;    
	return output+2;    
}  

char * put_be24(char *output,uint32_t nVal )    
{    
	output[2] = nVal & 0xff;    
	output[1] = nVal >> 8;    
	output[0] = nVal >> 16;    
	return output+3;    
}    
char * put_be32(char *output, uint32_t nVal )    
{    
	output[3] = nVal & 0xff;    
	output[2] = nVal >> 8;    
	output[1] = nVal >> 16;    
	output[0] = nVal >> 24;    
	return output+4;    
}    
char *  put_be64( char *output, uint64_t nVal )    
{    
	output=put_be32( output, nVal >> 32 );    
	output=put_be32( output, nVal );    
	return output;    
}  

char * put_amf_string( char *c, const char *str )    
{    
	uint16_t len = strlen( str );    
	c=put_be16( c, len );    
	memcpy(c,str,len);    
	return c+len;    
}    
char * put_amf_double( char *c, double d )    
{    
	*c++ = AMF_NUMBER;  /* type: Number */    
	{    
		unsigned char *ci, *co;    
		ci = (unsigned char *)&d;    
		co = (unsigned char *)c;    
		co[0] = ci[7];    
		co[1] = ci[6];    
		co[2] = ci[5];    
		co[3] = ci[4];    
		co[4] = ci[3];    
		co[5] = ci[2];    
		co[6] = ci[1];    
		co[7] = ci[0];    
	}    
	return c+8;    
}  



int dms_handle ;
int	nReaderId = 0; 
unsigned int  nalhead_pos;
RTMP* m_pRtmp;  
RTMPMetadata metaData;
int ret = 0;
int rtmp_connect_state = 0;
pthread_t    rtmp_push_threadId;
DMS_NET_DATA_PACKET stDataPacket;
unsigned char *buf_tmp;

int tail_state = false;





int ASJ_RTMP_Init(const char* url){
	if(RTMP264_Connect(url)){
		rtmp_connect_state = 1;
		printf("RTMP Connect success !!!!\n");
	  
	ret=pthread_create(&rtmp_push_threadId, NULL , (void *)RTMPPushThread, NULL);
	  if(ret != 0){
		printf("Create RTMP PUSH Thread file !!!!!!!\n");
		RTMP264_Close();
		return false;
	   }
	}
	else{
		rtmp_connect_state = 0;
		printf("RTMP Connect file !!!!\n");
	}
	return true; 
}

int RTMP264_Connect(const char* url)  
{  
	nalhead_pos=0;
	/*buf_size=BUFFER_SIZE;
	buf=(unsigned char*)malloc(BUFFER_SIZE);
	buf_tmp=(unsigned char*)malloc(BUFFER_SIZE);*/
	InitSockets();  

	m_pRtmp = RTMP_Alloc();
	RTMP_Init(m_pRtmp);
	
	if (RTMP_SetupURL(m_pRtmp,(char*)url) == FALSE)
	{
		RTMP_Free(m_pRtmp);
		return false;
	}
	
	RTMP_EnableWrite(m_pRtmp);
	
	if (RTMP_Connect(m_pRtmp, NULL) == FALSE) 
	{
		RTMP_Free(m_pRtmp);
		return false;
	} 

	
	if (RTMP_ConnectStream(m_pRtmp,0) == FALSE)
	{
		RTMP_Close(m_pRtmp);
		RTMP_Free(m_pRtmp);
		return false;
	}
	return true;  
}  

    
void RTMP264_Close()  
{  
	if(m_pRtmp)  
	{  
		RTMP_Close(m_pRtmp);  
		RTMP_Free(m_pRtmp);  
		m_pRtmp = NULL;  
	}  
	CleanupSockets();   
} 



/**
 *  ������������Nalu,��ͷ�±�nalhead_pos��Ϊ0ʱ����
 *
 */ 
int ReadNaluFromBuf(NaluUnit *nalu,unsigned char *buf, unsigned int  buf_size) 
{
    
	int naltail_pos=nalhead_pos;
	int nalustart;
	if(buf_tmp != NULL){
       free(buf_tmp);
	}
	buf_tmp=(unsigned char*)malloc(buf_size);
	memset(buf_tmp,0,buf_size);
	nalu->size=0;
				
		while(naltail_pos<buf_size)  
		{  
				
			if(buf[naltail_pos++] == 0x00 && 
				buf[naltail_pos++] == 0x00) 
			{
							
				if(buf[naltail_pos++] == 0x00 && 
					buf[naltail_pos++] == 0x01)
				{
					nalustart=4;
					goto gotnal;
				}
				else
				continue;
				
			}
			else
              continue;
			
				

			gotnal:	
 				
					nalu->type = buf[nalhead_pos]&0x1f; 
					nalu->size=naltail_pos-nalhead_pos-nalustart;
					if(nalu->type==0x06)
					{
						nalhead_pos=naltail_pos;
						continue;
					}
					memcpy(buf_tmp,buf+nalhead_pos,nalu->size+1);
					nalu->data=buf_tmp;
					nalhead_pos=naltail_pos;
					return TRUE;    
								
		}

		
		
		if(naltail_pos>=buf_size && nalhead_pos<buf_size)
		{ 
            nalu->size = buf_size - nalhead_pos;
			nalu->type = buf[nalhead_pos]&0x1f; 
		    memcpy(buf_tmp,buf+nalhead_pos,nalu->size+1);
			nalu->size = FindNaluFromNextPacket(nalu->size,buf_size);
			nalhead_pos = 0; 
			if(nalu->size == FALSE){
              printf("FindNaluFromNextPacket file \n");
			  return FALSE;
			}
			return TRUE;
		}
      
		if(naltail_pos>=buf_size && nalhead_pos>=buf_size){
			nalhead_pos = 0;
            return FALSE;
		}
		
	return FALSE;  
}

/**
 *  ������������һ��Nalu,��ͷ�±�nalhead_posΪ0ʱ����
 *
 */ 
int ReadFirstNaluFromBuf(NaluUnit *nalu,unsigned char *buf, unsigned int  buf_size) 
{
    
	int naltail_pos=nalhead_pos;
	
	if(buf_tmp != NULL){
       free(buf_tmp);
	}
	buf_tmp=(unsigned char*)malloc(buf_size);
	memset(buf_tmp,0,buf_size);
	//Naluͷ��־Ϊ00000001��ͷ�±��ҵ���һ��Naluͷ��־
	while(nalhead_pos<buf_size)  
	{  
	    
		if(buf[nalhead_pos++] == 0x00 && 
			buf[nalhead_pos++] == 0x00) 
		{ 	
				if(buf[nalhead_pos++] == 0x00 && 
					buf[nalhead_pos++] == 0x01 ){
				   goto gotnal_head;
				}
				
				else
					continue;
		 }
		else 
			continue;

		
gotnal_head:
		//β�±��ҵ���һ��Naluͷ��־
		naltail_pos = nalhead_pos;  
		while (naltail_pos<buf_size)  
		{  
			if(buf[naltail_pos++] == 0x00 && 
				buf[naltail_pos++] == 0x00 )
			{  
					if(buf[naltail_pos++] == 0x00 &&
						buf[naltail_pos++] == 0x01)
					{	
						nalu->size = (naltail_pos-4)-nalhead_pos;
						break;
					}
			}  
		}
        //�ڴ��������Ҳ�����һ��Naluͷ��־��˵������һ�������д�Nalu����
		if(nalhead_pos<buf_size && naltail_pos>=buf_size ){
			nalu->size = buf_size - nalhead_pos;
			nalu->type = buf[nalhead_pos]&0x1f; 
		    memcpy(buf_tmp,buf+nalhead_pos,nalu->size+1);//�Ȱ��������Nalu���ݱ�������
			nalu->size = FindNaluFromNextPacket(nalu->size,buf_size);//���Ͻ��������NALUʣ�����ݷŵ�buf_tmp�У��Ա�һ����
			nalhead_pos = 0;//FindNaluFromNextPacket�����������к��ָ��ض�ָ���µ���������������0���µ��ñ�������
			if(nalu->size == FALSE){
              printf("FindNaluFromNextPacket file \n");
			  return false;
			}
		}
        //�ڴ������ҵ���һ��Naluͷ��־
		if(nalhead_pos<buf_size && naltail_pos<buf_size){
		 nalu->type = buf[nalhead_pos]&0x1f;
		 memcpy(buf_tmp,buf+nalhead_pos,nalu->size+1);
         nalhead_pos=naltail_pos;
		}

		nalu->data=buf_tmp;
		return true;   		
	}
	return true;
}


int FindNaluFromNextPacket(int size,unsigned int buf_size){
	int s32Ret = -1;
	int nal_pos = 0;
	int nalustate = TRUE;
	do{//�ҵ���һNALUͷΪֹ
	nal_pos = 0;
    s32Ret=dms_sysnetapi_MBUF_GetReadPtrPos(dms_handle,nReaderId, DMS_MBUF_POS_CUR_READ, 0, &stDataPacket);//��ȡ��һ��������
	if(s32Ret != DMS_SUCCESS){
       printf("reset ReadPtrPos file !!!\n");
	}
	while(nal_pos<stDataPacket.dwPacketSize)  
	{  
	    
		if(stDataPacket.pData[nal_pos++] == 0x00 && 
			stDataPacket.pData[nal_pos++] == 0x00) 
		{ 	
				if(stDataPacket.pData[nal_pos++] == 0x00 && 
					stDataPacket.pData[nal_pos++] == 0x01 ){
				   nalustate = FALSE;
				   break;
				}
				
				else
					continue;
		 }
		else 
			continue;

	}
	//��buf_tmp���������Է�����һNALUʣ������
	if(nalustate && nal_pos>=stDataPacket.dwPacketSize){
      if((buf_tmp = (unsigned char*)realloc(buf_tmp,nal_pos+buf_size)) == NULL){
         return FALSE;
      }
	  memcpy(buf_tmp+size,stDataPacket.pData,nal_pos+1);
	  size = size + nal_pos;//��¼NALU����
	  buf_size = nal_pos + buf_size;//��¼BUFFER����������������
	}
	
	}while(nalustate);
	return size;
}





 
int SendVideoSpsPps(unsigned char *pps,int pps_len,unsigned char * sps,int sps_len)
{
	RTMPPacket * packet=NULL;
	unsigned char * body=NULL;
	int i;
	packet = (RTMPPacket *)malloc(RTMP_HEAD_SIZE+1024);
	//RTMPPacket_Reset(packet);
	memset(packet,0,RTMP_HEAD_SIZE+1024);
	packet->m_body = (char *)packet + RTMP_HEAD_SIZE;
	body = (unsigned char *)packet->m_body;
	i = 0;
	body[i++] = 0x17;
	body[i++] = 0x00;

	body[i++] = 0x00;
	body[i++] = 0x00;
	body[i++] = 0x00;

	/*AVCDecoderConfigurationRecord*/
	body[i++] = 0x01;
	body[i++] = sps[1];
	body[i++] = sps[2];
	body[i++] = sps[3];
	body[i++] = 0xff;

	/*sps*/
	body[i++]   = 0xe1;
	body[i++] = (sps_len >> 8) & 0xff;
	body[i++] = sps_len & 0xff;
	memcpy(&body[i],sps,sps_len);
	i +=  sps_len;

	/*pps*/
	body[i++]   = 0x01;
	body[i++] = (pps_len >> 8) & 0xff;
	body[i++] = (pps_len) & 0xff;
	memcpy(&body[i],pps,pps_len);
	i +=  pps_len;

	packet->m_packetType = RTMP_PACKET_TYPE_VIDEO;
	packet->m_nBodySize = i;
	packet->m_nChannel = 0x04;
	packet->m_nTimeStamp = 0;
	packet->m_hasAbsTimestamp = 0;
	packet->m_headerType = RTMP_PACKET_SIZE_MEDIUM;
	packet->m_nInfoField2 = m_pRtmp->m_stream_id;

	
	int nRet = RTMP_SendPacket(m_pRtmp,packet,FALSE);
	free(packet);    
	return nRet;
}

int SendPacket(unsigned int nPacketType,unsigned char *data,unsigned int size,unsigned int nTimestamp)  
{  
	RTMPPacket* packet;
	/*������ڴ�ͳ�ʼ��,lenΪ���峤��*/
	packet = (RTMPPacket *)malloc(RTMP_HEAD_SIZE+size);
	memset(packet,0,RTMP_HEAD_SIZE);
	/*�����ڴ�*/
	packet->m_body = (char *)packet + RTMP_HEAD_SIZE;
	packet->m_nBodySize = size;
	memcpy(packet->m_body,data,size);
	packet->m_hasAbsTimestamp = 0;
	packet->m_packetType = nPacketType; /*�˴�Ϊ����������һ������Ƶ,һ������Ƶ*/
	packet->m_nInfoField2 = m_pRtmp->m_stream_id;
	packet->m_nChannel = 0x04;

	packet->m_headerType = RTMP_PACKET_SIZE_LARGE;

	if (RTMP_PACKET_TYPE_AUDIO ==nPacketType && size !=4)
	{
		packet->m_headerType = RTMP_PACKET_SIZE_MEDIUM;
	}
	packet->m_nTimeStamp = nTimestamp;
	/*����*/
	int nRet =0;
	if (RTMP_IsConnected(m_pRtmp))
	{
		nRet = RTMP_SendPacket(m_pRtmp,packet,FALSE); /*TRUEΪ�Ž����Ͷ���,FALSE�ǲ��Ž����Ͷ���,ֱ�ӷ���*/
	}
	/*�ͷ��ڴ�*/
	free(packet);
	return nRet;  
}  


int SendH264Packet(unsigned char *data,unsigned int size,int bIsKeyFrame,unsigned int nTimeStamp)  
{  
    int i = 0; 
   // int h;
	if(data == NULL && size<11){  
		return false;  
	}
	
	unsigned char *body = (unsigned char*)malloc(size+10);  
	memset(body,0,size+10);

	if(bIsKeyFrame){  
		body[i++] = 0x17;// 1:Iframe  7:AVC   
		body[i++] = 0x01;// AVC NALU   
		body[i++] = 0x00;  
		body[i++] = 0x00;  
		body[i++] = 0x00;  


		// NALU size   
		body[i++] = size>>24 &0xff;  
		body[i++] = size>>16 &0xff;  
		body[i++] = size>>8 &0xff;  
		body[i++] = size&0xff;
		// NALU data
		
		memcpy(&body[i],data,size+1);
		//body[size+10]='\0';
		SendVideoSpsPps(metaData.Pps,metaData.nPpsLen,metaData.Sps,metaData.nSpsLen);
		
	}else{  
		body[i++] = 0x27;// 2:Pframe  7:AVC   
		body[i++] = 0x01;// AVC NALU   
		body[i++] = 0x00;  
		body[i++] = 0x00;  
		body[i++] = 0x00;  


		// NALU size   
		body[i++] = size>>24 &0xff;  
		body[i++] = size>>16 &0xff;  
		body[i++] = size>>8 &0xff;  
		body[i++] = size&0xff;
		// NALU data 
		memcpy(&body[i],data,size+1);
        //body[size+10]='\0';
	}
	
    //printf("body data tail %02x %02x\n",body[9+size],body[10+size]); 
	int bRet = SendPacket(RTMP_PACKET_TYPE_VIDEO,body,10+size,nTimeStamp);  
  
	free(body);  

	return bRet;  
} 



void RTMPPushThread(){
	int s32Ret = DMS_SUCCESS;
	int u32MaxGetKeyFrameFailedNum = 0;
	unsigned char* databuffer;
	unsigned int dataSize;
	NaluUnit  naluUnit;
	int bKeyframe;
	
	
	memset(&metaData,0,sizeof(RTMPMetadata));
	while(rtmp_connect_state){
		printf(" #### First get Data ####\n");
		memset(&stDataPacket, 0, sizeof(stDataPacket));
        s32Ret = dms_sysnetapi_MBUF_GetReadPtrPos(dms_handle,nReaderId, DMS_MBUF_POS_LAST_WRITE_nIFRAME, 0, &stDataPacket);		
        
		if(s32Ret != DMS_SUCCESS){
			u32MaxGetKeyFrameFailedNum++;
			if(u32MaxGetKeyFrameFailedNum > 100){
              rtmp_connect_state = 0;	
			  printf("Max get KeyFrame Faile\n");	
			}
		}
		databuffer = stDataPacket.pData;
		dataSize = stDataPacket.dwPacketSize;
      
		
      //ȡSPS��PPS֡Ȼ����
     ReadFirstNaluFromBuf(&naluUnit,databuffer,dataSize);
	 metaData.nSpsLen = naluUnit.size;  
	 metaData.Sps=NULL;
 	 metaData.Sps=(unsigned char*)malloc(naluUnit.size);
	 memcpy(metaData.Sps,naluUnit.data,naluUnit.size);
	
	 ReadNaluFromBuf(&naluUnit,databuffer,dataSize);
	 //ReadNaluFromBuf(&naluUnit,databuffer,dataSize);
	 metaData.nPpsLen = naluUnit.size; 
	 metaData.Pps=NULL;
	 metaData.Pps=(unsigned char*)malloc(naluUnit.size);
	 memcpy(metaData.Pps,naluUnit.data,naluUnit.size);
	 metaData.nFrameRate = 12;//������Ҫ��ȡһ��ʵʱ��ȷ��֡�ʣ���ô�SPS��PPS������������֡�ʹ̶���������ʱ��ֵ
   
	 s32Ret=SendVideoSpsPps(metaData.Pps,metaData.nPpsLen,metaData.Sps,metaData.nSpsLen);
	 if(s32Ret!=1)
		printf("Send SPS PPS FILE !!!\n");
	 
	 unsigned int tick = 0;  
	 unsigned int tick_gap = 1000/metaData.nFrameRate;

	 ReadNaluFromBuf(&naluUnit,databuffer,dataSize);
	 bKeyframe  = (naluUnit.type == 0x05) ? TRUE : FALSE;
	while(SendH264Packet(naluUnit.data,naluUnit.size,bKeyframe,tick))  
	{    
	 get_pps_sps : 

		if(nalhead_pos == 0){
         ReadFirstNaluFromBuf(&naluUnit,stDataPacket.pData,stDataPacket.dwPacketSize);
		}
		else{
         ReadNaluFromBuf(&naluUnit,stDataPacket.pData,stDataPacket.dwPacketSize);
		}
		 
		//��ӡ����PPS��SPS ����û�䣬��֮�����б���ڴ˴�����PPS��SPS�������·��� 
	   if(naluUnit.type == 0x07 || naluUnit.type == 0x08){
		  goto get_pps_sps;
	   }
		
       bKeyframe  = (naluUnit.type == 0x05) ? TRUE : FALSE;
	   tick +=tick_gap;	
    
	} 

  }
	free(metaData.Sps);
	free(metaData.Pps);
	dms_sysnetapi_MBUF_DelReader(dms_handle,nReaderId);
	RTMP264_Close();
}


