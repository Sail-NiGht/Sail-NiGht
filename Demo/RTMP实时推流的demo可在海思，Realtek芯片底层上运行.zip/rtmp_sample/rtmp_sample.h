


int RTMP264_Connect(const char* url);    
int RTMP264_Send(int (*read_buffer)(unsigned char *buf, int buf_size));
void RTMP264_Close();
void RTMPPushThread();
int SendVideoSpsPps(unsigned char *pps,int pps_len,unsigned char * sps,int sps_len);
int SendH264Packet(unsigned char *data,unsigned int size,int bIsKeyFrame,unsigned int nTimeStamp);
/*int ReadFirstNaluFromBuf(NaluUnit *nalu,unsigned char *buf, unsigned int  buf_size) ;
int ReadNaluFromBuf(NaluUnit *nalu,unsigned char *buf, unsigned int  buf_size) ;*/
int FindNaluFromNextPacket(int size,unsigned int buf_size);
int SendPacket(unsigned int nPacketType,unsigned char *data,unsigned int size,unsigned int nTimestamp);
int rtmp_Init(const char* url);