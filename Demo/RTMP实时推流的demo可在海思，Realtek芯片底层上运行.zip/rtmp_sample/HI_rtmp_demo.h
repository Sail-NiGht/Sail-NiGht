/**
 * 初始化并连接到服务器
 *
 * @param url 服务器上对应webapp的地址
 *					
 * @成功则返�? , 失败则返�?
 */ 
int RTMP264_Connect(const char* url);    
    
/**
 * 将内存中的一段H.264编码的视频数据利用RTMP协议发送到服务�?
 *
 * @param read_buffer 回调函数，当数据不足的时候，系统会自动调用该函数获取输入数据�?
 *					2个参数功能：
 *					uint8_t *buf：外部数据送至该地址
 *					int buf_size：外部数据大�?
 *					返回值：成功读取的内存大�?
 * @成功则返�? , 失败则返�?
 */ 
int RTMP264_Send(int (*read_buffer)(unsigned char *buf, int buf_size));

/**
 * 断开连接，释放相关的资源�?
 *
 */    
void RTMP264_Close();
void RTMPPushThread();
int SendVideoSpsPps(unsigned char *pps,int pps_len,unsigned char * sps,int sps_len);
int SendH264Packet(unsigned char *data,unsigned int size,int bIsKeyFrame,unsigned int nTimeStamp);
int FindNaluFromNextPacket(int size,unsigned int buf_size);
int SendPacket(unsigned int nPacketType,unsigned char *data,unsigned int size,unsigned int nTimestamp);
int Gree_rtmp_Init(const char* url);